<?php

    /****************************************************************************
     **                               MySQLi or PDO                            **
     ***************************************************************************/
    /* Data Connection Properties */

	define("DBTYPE", $conf['db_type']);             /* Connection Type */
	define("HOSTNAME", $conf['db_hostname']);       /* Hostname */
	define("DBPORT", $conf['db_port']);             /* Port */
	define("HOSTUSER", $conf['db_username']);       /* Database Username */
	define("HOSTPASS", $conf['db_password']);       /* Database User Password */
	define("DBNAME", $conf['db_name']);             /* Database Name */