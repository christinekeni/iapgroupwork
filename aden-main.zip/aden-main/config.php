<?php

$conf["site_name"] = "ICS 2.2";
$conf["au_email_address"] = "info@icsd.rochella.org";

$conf['db_type'] = "PDO";             /* Connection Type */
$conf['db_hostname'] = "localhost";       /* Hostname */
$conf['db_port'] = "3306";             /* Port */
$conf['db_username'] = "root";       /* Database Username */
$conf['db_password'] = "";       /* Database User Password */
$conf['db_name'] = "aden";             /* Database Name */